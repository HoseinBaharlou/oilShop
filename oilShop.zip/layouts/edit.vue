<template>
<v-app>
  <v-main>
    <v-container class="fill-height justify-center">
      <nuxt/>
    </v-container>
  </v-main>
</v-app>
</template>

<script>
export default {
  name: "edit"
}
</script>

<style scoped>

</style>
