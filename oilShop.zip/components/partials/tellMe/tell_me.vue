<template>
    <v-row class="align-center">
        <!-- company information -->
        <v-col cols="12" md="6">
            <!-- email -->
            <p class="text-md-right text-center deep-purple--text font-size-30 font-size-sm-20">
                <span>ایمیل:</span>
                <a href="mailto:aminpalayeshisatis@gmail.com" class="text-decoration-none deep-purple--text">aminpalayeshisatis@gmail.com</a>
            </p> 
            <!-- phone -->
            <p class="text-md-right text-center deep-purple--text font-size-30 font-size-sm-20">
                <span>شماره تماس:</span>
                <span>09941332497</span>
            </p>
            <!-- address -->
            <p class="text-md-right text-center deep-purple--text font-size-30 font-size-sm-20">
                <span>آدرس:</span>
                <span>ایران/تهران</span>
            </p>
        </v-col>
        <!-- logo -->
        <v-col cols="12" md="6" class="d-flex justify-center">
            <v-img src="image/WhatsApp Image 2021-02-14 at 10.56.03.png" lazy-src="image/WhatsApp Image 2021-02-14 at 10.56.03.png" max-height="403" max-width="403"/>
        </v-col>
        <!-- start map -->
        <v-col cols="12" class="mt-17">
            <div style="width: 100%"><iframe width="100%" height="600" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=1%20Grafton%20Street,%20Dublin,%20Ireland+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"><a href="https://www.gps.ie/wearable-gps/">wearable gps</a></iframe></div>
        </v-col>
    </v-row>
</template>