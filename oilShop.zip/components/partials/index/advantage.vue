<template>
    <v-container>
        <!-- start title and description -->
        <h1 class="font-size-md-36 text-center">مزیت امین پالایش ایساتیس</h1>

        <p class="mt-5 text-center grey-darken-4--text">
            لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
        </p>
        <!-- end title and description -->

        <!-- start advantage -->
        <article class="mt-17">
            <v-row class="mt-17">
                <!-- start title and description -->
                <v-col md="6" cols="12">
                    <v-badge color="purple darken-2" left offset-y="18" class="mx-4" content="1">
                        <span class="mx-4">لورم ایپسوم</span>
                    </v-badge>

                    <h2 class="mt-5">لورم ایپسوم</h2>

                    <p class="text-justify mt-4 font-size-12">
                        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
                    </p>

                    <div class="d-flex justify-end">
                        <v-btn color="purple darken-2" class="white--text px-15 rounded-xl font-size-14" large elevation="0">مقالات</v-btn>
                    </div>
                </v-col>
                <!-- end title and description -->

                <!-- start image -->
                <v-col cols="6" class="d-none d-md-flex justify-center">
                    <v-img src="image/barrel-5989257.svg" lazy-src="image/barrel-5989257.svg" max-height="294" max-width="294" />
                </v-col>
                <!-- end image -->
            </v-row>
        </article>

        <article class="mt-21">
            <v-row class="mt-17 align-center">
                <!-- start image -->
                <v-col cols="6" class="d-none d-md-flex justify-center">
                    <v-img src="image/barrel-5989257.svg" lazy-src="image/barrel-5989257.svg" max-height="294" max-width="294" />
                </v-col>
                <!-- end image -->

                <!-- start title and description -->
                <v-col md="6" cols="12">
                    <v-badge color="purple darken-2" left offset-y="18" class="mx-4" content="1">
                        <span class="mx-4">لورم ایپسوم</span>
                    </v-badge>

                    <h2 class="mt-5">لورم ایپسوم</h2>

                    <p class="text-justify mt-4 font-size-12">
                        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
                    </p>

                    <div class="d-flex justify-end">
                        <v-btn color="purple darken-2" class="white--text px-15 rounded-xl font-size-14" large elevation="0">مقالات</v-btn>
                    </div>
                </v-col>
                <!-- end title and description -->
            </v-row>
        </article>

        <article class="mt-21">
            <v-row class="mt-17">
                <!-- start title and description -->
                <v-col md="6" cols="12">
                    <v-badge color="purple darken-2" left offset-y="18" class="mx-4" content="1">
                        <span class="mx-4">لورم ایپسوم</span>
                    </v-badge>

                    <h2 class="mt-5">لورم ایپسوم</h2>

                    <p class="text-justify mt-4 font-size-12">
                        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد.
                    </p>

                    <div class="d-flex justify-end">
                        <v-btn color="purple darken-2" class="white--text px-15 rounded-xl font-size-14" large elevation="0">مقالات</v-btn>
                    </div>
                </v-col>
                <!-- end title and description -->

                <!-- start image -->
                <v-col cols="6" class="d-none d-md-flex justify-center">
                    <v-img src="image/barrel-5989257.svg" lazy-src="image/barrel-5989257.svg" max-height="294" max-width="294" />
                </v-col>
                <!-- end image -->
            </v-row>
        </article>
        <!-- end advantage -->
    </v-container>
</template>