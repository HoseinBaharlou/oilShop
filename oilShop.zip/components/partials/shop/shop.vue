<template>
  <article>
    <v-img :src="image" :alt="image_alt">
      <v-row>
        <v-col cols="12">

        </v-col>
      </v-row>
    </v-img>
  </article>
</template>

<script>
export default {
  name: "shop",
  props:['image','image_alt']
}
</script>

<style scoped>

</style>
