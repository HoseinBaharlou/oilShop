<template>
  <v-card class="rounded-xl">
    <!-- start title -->
    <v-card-title>
      <h3>بالانس نفت برنت</h3>
    </v-card-title>
    <!-- end title -->

    <!-- start actions -->
    <v-divider class="mx-4"></v-divider>
    <v-card-actions class="d-block">
      <span class="grey--text">مجموع:</span>
      <h1 class="text-center">84.564610</h1>
      <v-btn small class="blue--text white" elevation="0">
        <v-icon>mdi-history</v-icon>
        تاریخچه معاملات
      </v-btn>
    </v-card-actions>
  <!-- end actions -->
  </v-card>
</template>