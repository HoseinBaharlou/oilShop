<template>
  <v-container class="hidden-md-and-down">
    <v-row>
      <v-col col="12" class="mt-14">
        <v-btn fab light elevation="0" class="mx-2">
          <v-icon class="custom-color-icon">mdi-account-outline</v-icon>
        </v-btn>
        <v-btn fab light elevation="0" class="mx-2">
          <v-icon class="custom-color-icon">mdi-bell-outline</v-icon>
        </v-btn>
        <v-btn fab light elevation="0" class="mx-2">
          <v-icon class="custom-color-icon">mdi-magnify</v-icon>
        </v-btn>
      </v-col>
    </v-row>
  </v-container>
</template>