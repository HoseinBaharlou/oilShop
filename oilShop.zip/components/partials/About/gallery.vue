<template>
    <v-row>
        <v-col cols="12" md="4">
            <v-img src="image/Rectangle 240.png" lazy-src="image/Rectangle 240.png" />
        </v-col>

        <v-col cols="12" md="4">
            <v-img src="image/Rectangle 240.png" lazy-src="image/Rectangle 240.png" />
        </v-col>

        <v-col cols="12" md="4">
            <v-img src="image/Rectangle 242.png" lazy-src="image/Rectangle 242.png" />
        </v-col>
    </v-row>
</template>