const middleware = {}

middleware['auth'] = require('..\\middleware\\auth.js')
middleware['auth'] = middleware['auth'].default || middleware['auth']

middleware['check-auth'] = require('..\\middleware\\check-auth.js')
middleware['check-auth'] = middleware['check-auth'].default || middleware['check-auth']

middleware['check-permission'] = require('..\\middleware\\check-permission.js')
middleware['check-permission'] = middleware['check-permission'].default || middleware['check-permission']

middleware['check-verify'] = require('..\\middleware\\check-verify.js')
middleware['check-verify'] = middleware['check-verify'].default || middleware['check-verify']

export default middleware
