import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _479f2b42 = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _68b033c4 = () => interopDefault(import('..\\pages\\analyze.vue' /* webpackChunkName: "pages/analyze" */))
const _11b08d24 = () => interopDefault(import('..\\pages\\gallery.vue' /* webpackChunkName: "pages/gallery" */))
const _5a59af8c = () => interopDefault(import('..\\pages\\Newsletters.vue' /* webpackChunkName: "pages/Newsletters" */))
const _6be67984 = () => interopDefault(import('..\\pages\\post\\index.vue' /* webpackChunkName: "pages/post/index" */))
const _2b6bf0b8 = () => interopDefault(import('..\\pages\\tell_me.vue' /* webpackChunkName: "pages/tell_me" */))
const _61d63ada = () => interopDefault(import('..\\pages\\auth\\login.vue' /* webpackChunkName: "pages/auth/login" */))
const _0dbbc969 = () => interopDefault(import('..\\pages\\auth\\register.vue' /* webpackChunkName: "pages/auth/register" */))
const _40bfdbbf = () => interopDefault(import('..\\pages\\auth\\verify.vue' /* webpackChunkName: "pages/auth/verify" */))
const _661a5724 = () => interopDefault(import('..\\pages\\dashboard\\calendar.vue' /* webpackChunkName: "pages/dashboard/calendar" */))
const _c4b1daf2 = () => interopDefault(import('..\\pages\\dashboard\\fileManager\\index.vue' /* webpackChunkName: "pages/dashboard/fileManager/index" */))
const _b959f9c2 = () => interopDefault(import('..\\pages\\dashboard\\main.vue' /* webpackChunkName: "pages/dashboard/main" */))
const _0ac8f20c = () => interopDefault(import('..\\pages\\dashboard\\mainHeader.vue' /* webpackChunkName: "pages/dashboard/mainHeader" */))
const _a1b3761e = () => interopDefault(import('..\\pages\\dashboard\\Message.vue' /* webpackChunkName: "pages/dashboard/Message" */))
const _68572fb3 = () => interopDefault(import('..\\pages\\dashboard\\Payments.vue' /* webpackChunkName: "pages/dashboard/Payments" */))
const _3b91c2c6 = () => interopDefault(import('..\\pages\\dashboard\\role-manager\\index.vue' /* webpackChunkName: "pages/dashboard/role-manager/index" */))
const _0cb2d7b9 = () => interopDefault(import('..\\pages\\dashboard\\SettingMenu.vue' /* webpackChunkName: "pages/dashboard/SettingMenu" */))
const _38862173 = () => interopDefault(import('..\\pages\\dashboard\\Tradeview.vue' /* webpackChunkName: "pages/dashboard/Tradeview" */))
const _27146a11 = () => interopDefault(import('..\\pages\\dashboard\\user-manager.vue' /* webpackChunkName: "pages/dashboard/user-manager" */))
const _7183a310 = () => interopDefault(import('..\\pages\\user\\profile.vue' /* webpackChunkName: "pages/user/profile" */))
const _03f08872 = () => interopDefault(import('..\\pages\\dashboard\\comment\\list.vue' /* webpackChunkName: "pages/dashboard/comment/list" */))
const _6bf129fc = () => interopDefault(import('..\\pages\\dashboard\\post\\create.vue' /* webpackChunkName: "pages/dashboard/post/create" */))
const _074b45b8 = () => interopDefault(import('..\\pages\\dashboard\\post\\list.vue' /* webpackChunkName: "pages/dashboard/post/list" */))
const _212aeea2 = () => interopDefault(import('..\\pages\\dashboard\\post\\trash.vue' /* webpackChunkName: "pages/dashboard/post/trash" */))
const _71963375 = () => interopDefault(import('..\\pages\\dashboard\\product\\create.vue' /* webpackChunkName: "pages/dashboard/product/create" */))
const _11d6a657 = () => interopDefault(import('..\\pages\\dashboard\\product\\list.vue' /* webpackChunkName: "pages/dashboard/product/list" */))
const _89906862 = () => interopDefault(import('..\\pages\\dashboard\\product\\trash.vue' /* webpackChunkName: "pages/dashboard/product/trash" */))
const _25f468a4 = () => interopDefault(import('..\\pages\\dashboard\\post\\_id.vue' /* webpackChunkName: "pages/dashboard/post/_id" */))
const _dbfea5de = () => interopDefault(import('..\\pages\\dashboard\\product\\_id.vue' /* webpackChunkName: "pages/dashboard/product/_id" */))
const _c7c482a4 = () => interopDefault(import('..\\pages\\dashboard\\role-manager\\_id.vue' /* webpackChunkName: "pages/dashboard/role-manager/_id" */))
const _69e5e628 = () => interopDefault(import('..\\pages\\post\\_id.vue' /* webpackChunkName: "pages/post/_id" */))
const _71dee426 = () => interopDefault(import('..\\pages\\shop\\_slug.vue' /* webpackChunkName: "pages/shop/_slug" */))
const _082f75b8 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _479f2b42,
    name: "about"
  }, {
    path: "/analyze",
    component: _68b033c4,
    name: "analyze"
  }, {
    path: "/gallery",
    component: _11b08d24,
    name: "gallery"
  }, {
    path: "/Newsletters",
    component: _5a59af8c,
    name: "Newsletters"
  }, {
    path: "/post",
    component: _6be67984,
    name: "post"
  }, {
    path: "/tell_me",
    component: _2b6bf0b8,
    name: "tell_me"
  }, {
    path: "/auth/login",
    component: _61d63ada,
    name: "auth-login"
  }, {
    path: "/auth/register",
    component: _0dbbc969,
    name: "auth-register"
  }, {
    path: "/auth/verify",
    component: _40bfdbbf,
    name: "auth-verify"
  }, {
    path: "/dashboard/calendar",
    component: _661a5724,
    name: "dashboard-calendar"
  }, {
    path: "/dashboard/fileManager",
    component: _c4b1daf2,
    name: "dashboard-fileManager"
  }, {
    path: "/dashboard/main",
    component: _b959f9c2,
    name: "dashboard-main"
  }, {
    path: "/dashboard/mainHeader",
    component: _0ac8f20c,
    name: "dashboard-mainHeader"
  }, {
    path: "/dashboard/Message",
    component: _a1b3761e,
    name: "dashboard-Message"
  }, {
    path: "/dashboard/Payments",
    component: _68572fb3,
    name: "dashboard-Payments"
  }, {
    path: "/dashboard/role-manager",
    component: _3b91c2c6,
    name: "dashboard-role-manager"
  }, {
    path: "/dashboard/SettingMenu",
    component: _0cb2d7b9,
    name: "dashboard-SettingMenu"
  }, {
    path: "/dashboard/Tradeview",
    component: _38862173,
    name: "dashboard-Tradeview"
  }, {
    path: "/dashboard/user-manager",
    component: _27146a11,
    name: "dashboard-user-manager"
  }, {
    path: "/user/profile",
    component: _7183a310,
    name: "user-profile"
  }, {
    path: "/dashboard/comment/list",
    component: _03f08872,
    name: "dashboard-comment-list"
  }, {
    path: "/dashboard/post/create",
    component: _6bf129fc,
    name: "dashboard-post-create"
  }, {
    path: "/dashboard/post/list",
    component: _074b45b8,
    name: "dashboard-post-list"
  }, {
    path: "/dashboard/post/trash",
    component: _212aeea2,
    name: "dashboard-post-trash"
  }, {
    path: "/dashboard/product/create",
    component: _71963375,
    name: "dashboard-product-create"
  }, {
    path: "/dashboard/product/list",
    component: _11d6a657,
    name: "dashboard-product-list"
  }, {
    path: "/dashboard/product/trash",
    component: _89906862,
    name: "dashboard-product-trash"
  }, {
    path: "/dashboard/post/:id?",
    component: _25f468a4,
    name: "dashboard-post-id"
  }, {
    path: "/dashboard/product/:id?",
    component: _dbfea5de,
    name: "dashboard-product-id"
  }, {
    path: "/dashboard/role-manager/:id?",
    component: _c7c482a4,
    name: "dashboard-role-manager-id"
  }, {
    path: "/post/:id",
    component: _69e5e628,
    name: "post-id"
  }, {
    path: "/shop/:slug?",
    component: _71dee426,
    name: "shop-slug"
  }, {
    path: "/",
    component: _082f75b8,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
