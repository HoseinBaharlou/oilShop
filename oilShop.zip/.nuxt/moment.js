import moment from 'moment-jalaali'

import 'moment/locale/fa'

moment.locale('fa')

moment.loadPersian({dialect: 'persian-modern'})

export default (ctx, inject) => {
  ctx.$moment = moment
  inject('moment', moment)
}
