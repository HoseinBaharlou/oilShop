export const isFullStatic = false
export const staticPath = "F:/oilShop/.nuxt/static-json"
export const publicPath = "/"
export const globalContext = "__NUXT__"
export const globalNuxt = "$nuxt"