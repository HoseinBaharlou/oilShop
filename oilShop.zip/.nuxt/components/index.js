export const NuxtLogo = () => import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c))
export const Tutorial = () => import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))
export const VuetifyLogo = () => import('../..\\components\\VuetifyLogo.vue' /* webpackChunkName: "components/vuetify-logo" */).then(c => wrapFunctional(c.default || c))
export const CommonFooter = () => import('../..\\components\\common\\footer.vue' /* webpackChunkName: "components/common-footer" */).then(c => wrapFunctional(c.default || c))
export const CommonNavbar = () => import('../..\\components\\common\\navbar.vue' /* webpackChunkName: "components/common-navbar" */).then(c => wrapFunctional(c.default || c))
export const PartialsAlert = () => import('../..\\components\\partials\\alert.vue' /* webpackChunkName: "components/partials-alert" */).then(c => wrapFunctional(c.default || c))
export const CommonMenuMobileMenu = () => import('../..\\components\\common\\menu\\mobile_menu.vue' /* webpackChunkName: "components/common-menu-mobile-menu" */).then(c => wrapFunctional(c.default || c))
export const PartialsAbout = () => import('../..\\components\\partials\\About\\about.vue' /* webpackChunkName: "components/partials-about" */).then(c => wrapFunctional(c.default || c))
export const PartialsAboutGallery = () => import('../..\\components\\partials\\About\\gallery.vue' /* webpackChunkName: "components/partials-about-gallery" */).then(c => wrapFunctional(c.default || c))
export const PartialsAnalyse = () => import('../..\\components\\partials\\analyse\\analyse.vue' /* webpackChunkName: "components/partials-analyse" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardCalendar = () => import('../..\\components\\partials\\dashboard\\Calendar.vue' /* webpackChunkName: "components/partials-dashboard-calendar" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardCandlestick = () => import('../..\\components\\partials\\dashboard\\candlestick.vue' /* webpackChunkName: "components/partials-dashboard-candlestick" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardContacts = () => import('../..\\components\\partials\\dashboard\\contacts.vue' /* webpackChunkName: "components/partials-dashboard-contacts" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardLinerChart = () => import('../..\\components\\partials\\dashboard\\linerChart.vue' /* webpackChunkName: "components/partials-dashboard-liner-chart" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardMessage = () => import('../..\\components\\partials\\dashboard\\Message.vue' /* webpackChunkName: "components/partials-dashboard-message" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardNavbarPreview = () => import('../..\\components\\partials\\dashboard\\navbarPreview.vue' /* webpackChunkName: "components/partials-dashboard-navbar-preview" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardNotification = () => import('../..\\components\\partials\\dashboard\\notification.vue' /* webpackChunkName: "components/partials-dashboard-notification" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardOilBalance = () => import('../..\\components\\partials\\dashboard\\oilBalance.vue' /* webpackChunkName: "components/partials-dashboard-oil-balance" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardTableFile = () => import('../..\\components\\partials\\dashboard\\table_file.vue' /* webpackChunkName: "components/partials-dashboard-table-file" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardTrafic = () => import('../..\\components\\partials\\dashboard\\Trafic.vue' /* webpackChunkName: "components/partials-dashboard-trafic" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardUnderMenu = () => import('../..\\components\\partials\\dashboard\\underMenu.vue' /* webpackChunkName: "components/partials-dashboard-under-menu" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardVlist = () => import('../..\\components\\partials\\dashboard\\vlist.vue' /* webpackChunkName: "components/partials-dashboard-vlist" */).then(c => wrapFunctional(c.default || c))
export const PartialsGallery = () => import('../..\\components\\partials\\gallery\\gallery.vue' /* webpackChunkName: "components/partials-gallery" */).then(c => wrapFunctional(c.default || c))
export const PartialsIndexAdvantage = () => import('../..\\components\\partials\\index\\advantage.vue' /* webpackChunkName: "components/partials-index-advantage" */).then(c => wrapFunctional(c.default || c))
export const PartialsIndexConsultant = () => import('../..\\components\\partials\\index\\consultant.vue' /* webpackChunkName: "components/partials-index-consultant" */).then(c => wrapFunctional(c.default || c))
export const PartialsIndexExpertComments = () => import('../..\\components\\partials\\index\\Expert_Comments.vue' /* webpackChunkName: "components/partials-index-expert-comments" */).then(c => wrapFunctional(c.default || c))
export const PartialsIndexHeader = () => import('../..\\components\\partials\\index\\header.vue' /* webpackChunkName: "components/partials-index-header" */).then(c => wrapFunctional(c.default || c))
export const PartialsIndexNotification = () => import('../..\\components\\partials\\index\\notification.vue' /* webpackChunkName: "components/partials-index-notification" */).then(c => wrapFunctional(c.default || c))
export const PartialsIndexProduct = () => import('../..\\components\\partials\\index\\product.vue' /* webpackChunkName: "components/partials-index-product" */).then(c => wrapFunctional(c.default || c))
export const PartialsIndexSlickCarousel = () => import('../..\\components\\partials\\index\\slick_carousel.vue' /* webpackChunkName: "components/partials-index-slick-carousel" */).then(c => wrapFunctional(c.default || c))
export const PartialsIndexTellMe = () => import('../..\\components\\partials\\index\\tell_me.vue' /* webpackChunkName: "components/partials-index-tell-me" */).then(c => wrapFunctional(c.default || c))
export const PartialsPostArticle = () => import('../..\\components\\partials\\post\\article.vue' /* webpackChunkName: "components/partials-post-article" */).then(c => wrapFunctional(c.default || c))
export const PartialsPostComment = () => import('../..\\components\\partials\\post\\comment.vue' /* webpackChunkName: "components/partials-post-comment" */).then(c => wrapFunctional(c.default || c))
export const PartialsPostFilter = () => import('../..\\components\\partials\\post\\filter.vue' /* webpackChunkName: "components/partials-post-filter" */).then(c => wrapFunctional(c.default || c))
export const PartialsPostPosts = () => import('../..\\components\\partials\\post\\posts.vue' /* webpackChunkName: "components/partials-post-posts" */).then(c => wrapFunctional(c.default || c))
export const PartialsPostSocialSahring = () => import('../..\\components\\partials\\post\\social_sahring.vue' /* webpackChunkName: "components/partials-post-social-sahring" */).then(c => wrapFunctional(c.default || c))
export const PartialsPostWriteComment = () => import('../..\\components\\partials\\post\\writeComment.vue' /* webpackChunkName: "components/partials-post-write-comment" */).then(c => wrapFunctional(c.default || c))
export const PartialsPostWriter = () => import('../..\\components\\partials\\post\\writer.vue' /* webpackChunkName: "components/partials-post-writer" */).then(c => wrapFunctional(c.default || c))
export const PartialsProfileAnalyze = () => import('../..\\components\\partials\\profile\\analyze.vue' /* webpackChunkName: "components/partials-profile-analyze" */).then(c => wrapFunctional(c.default || c))
export const PartialsProfileUserProfile = () => import('../..\\components\\partials\\profile\\user_profile.vue' /* webpackChunkName: "components/partials-profile-user-profile" */).then(c => wrapFunctional(c.default || c))
export const PartialsShop = () => import('../..\\components\\partials\\shop\\shop.vue' /* webpackChunkName: "components/partials-shop" */).then(c => wrapFunctional(c.default || c))
export const PartialsTellMe = () => import('../..\\components\\partials\\tellMe\\tell_me.vue' /* webpackChunkName: "components/partials-tell-me" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardHeaderImageHeader = () => import('../..\\components\\partials\\dashboard\\header\\imageHeader.vue' /* webpackChunkName: "components/partials-dashboard-header-image-header" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardHeaderSliderHeader = () => import('../..\\components\\partials\\dashboard\\header\\sliderHeader.vue' /* webpackChunkName: "components/partials-dashboard-header-slider-header" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardProductList = () => import('../..\\components\\partials\\dashboard\\product\\productList.vue' /* webpackChunkName: "components/partials-dashboard-product-list" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardRoleManagerCreateRole = () => import('../..\\components\\partials\\dashboard\\roleManager\\createRole.vue' /* webpackChunkName: "components/partials-dashboard-role-manager-create-role" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardRoleList = () => import('../..\\components\\partials\\dashboard\\roleManager\\roleList.vue' /* webpackChunkName: "components/partials-dashboard-role-list" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardUserManagerAddRole = () => import('../..\\components\\partials\\dashboard\\userManager\\addRole.vue' /* webpackChunkName: "components/partials-dashboard-user-manager-add-role" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardUserManagerEditUser = () => import('../..\\components\\partials\\dashboard\\userManager\\editUser.vue' /* webpackChunkName: "components/partials-dashboard-user-manager-edit-user" */).then(c => wrapFunctional(c.default || c))
export const PartialsDashboardUserManager = () => import('../..\\components\\partials\\dashboard\\userManager\\userManager.vue' /* webpackChunkName: "components/partials-dashboard-user-manager" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
