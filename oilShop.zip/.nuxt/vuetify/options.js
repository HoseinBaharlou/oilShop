export default {"rtl":true}
