<template>
  <v-simple-table>
    <template>
<!--      head-->
      <thead>
      <tr>
        <th>ای دی</th>
        <th>نام کاربر</th>
        <th>وضعیت</th>
        <th>زمان ارسال</th>
      </tr>
      </thead>
<!--      body-->
      <tbody>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      </tbody>
    </template>
  </v-simple-table>
</template>

<script>
export default {
  name: "list",
  layout:'dashboard'
}
</script>

<style scoped>

</style>
