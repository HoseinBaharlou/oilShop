<template>
  <section>
    <shop v-for="item in $store.getters.contents" :image="item.file" :image_alt="item.title"/>
  </section>
</template>

<script>
import shop from "@/components/partials/shop/shop";
export default {
  name: "_slug",
  async asyncData({store,$axios,route}){
    await $axios.get(`/categories/shop/${encodeURIComponent(route.params.slug)}`).then((res)=>{
      store.dispatch('contents',res.data.product[0][0])
    })
  },
  components:{shop}
}
</script>

<style scoped>

</style>
