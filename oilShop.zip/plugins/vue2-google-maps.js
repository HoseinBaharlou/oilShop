import Vue from 'vue'
import * as VueGoogleMaps from 'vue2-google-maps'
 
Vue.use(VueGoogleMaps, {
  load: {
    key: 'AIzaSyBdDNOpy5TVsi0i9ZifgTfAsqgwNAd3AdY',
  },
})
 