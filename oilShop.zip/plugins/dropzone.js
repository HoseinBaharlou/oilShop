import vue2Dropzone from 'vue2-dropzone'
import Vue from 'vue'

import 'vue2-dropzone/dist/vue2Dropzone.min.css'

Vue.component('vue2Dropzone', vue2Dropzone)