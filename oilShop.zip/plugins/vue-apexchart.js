import VueApexCharts from 'vue-apexcharts'
import Vue from 'vue'
Vue.component('apexchart', VueApexCharts)